USE signup_flow;

WITH
total_visitors as
(
	SELECT
		v.visitor_id,
		v.first_visit_date, 
        s.date_registered as registration_date,
        p.purchase_date
	FROM
		visitors as v
		LEFT JOIN
		students s on v.user_id = s.user_id
		LEFT JOIN
		student_purchases p on v.user_id = p.user_id

	GROUP BY visitor_id
	
),
count_visitors as
(
	SELECT
		first_visit_date as date_session,
        COUNT(*) as count_total_visitors
	FROM total_visitors 
    GROUP BY date_session
),

count_registered as
(
	SELECT
		v.first_visit_date as date_session,
        COUNT(*) as count_registered
	FROM total_visitors v
    WHERE registration_date IS NOT NULL
    GROUP BY date_session),
    
count_registered_free as
(
	SELECT
		v.first_visit_date as date_session,
        COUNT(*) as count_registered_free
	FROM total_visitors v
    WHERE registration_date IS NOT NULL
    and (purchase_date is null
    or TIMESTAMPDIFF(minute, registration_date, purchase_date) > 30)
    GROUP BY date_session)


SELECT
	v.date_session as date_session, 
    v.count_total_visitors,
    IFNULL(r.count_registered, 0) as count_registered,
	IFNULL(fr.count_registered_free, 0) as free_registered_users
FROM
	count_visitors as v
    LEFT JOIN
    count_registered as r ON v.date_session = r.date_session 
    LEFT JOIN
    count_registered_free as fr ON v.date_session = fr.date_session 

ORDER BY date_session;